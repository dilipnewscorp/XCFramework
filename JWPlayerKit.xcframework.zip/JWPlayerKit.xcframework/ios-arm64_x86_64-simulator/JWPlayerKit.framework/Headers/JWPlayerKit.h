//
//  JWPlayerKit.h
//
//  Copyright © 2020 JWPlayer. All rights reserved.
//

#import <Foundation/Foundation.h>
//! Project version number for JWPlayer_iOS_Native_SDK.
FOUNDATION_EXPORT double JWPlayerKitVersionNumber;

//! Project version string for JWPlayer_iOS_Native_SDK.
FOUNDATION_EXPORT const unsigned char JWPlayerKitVersionString[];

#import "OMIDImports.h"

